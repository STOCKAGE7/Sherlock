
#[derive(Clone, Debug)]
pub struct ModularEvent{
    pub icon: String,
    pub condition: String,
    pub method: String,
    pub exec: String,
    pub args: String,
}

impl ModularEvent {
    pub fn get_tile(){

    }
}
